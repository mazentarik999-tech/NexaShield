package com.nexashield.mobile

import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppFinding(
    val label: String,
    val packageName: String,
    val permissions: List<String>,
    val reasons: List<String>
)

class MainActivity : ComponentActivity() {
    private lateinit var content: TextView
    private lateinit var scanButton: Button
    private var lastReport = "لم يتم إجراء فحص بعد."

    private val apkPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) inspectApk(uri)
    }

    private val sensitivePermissions = linkedMapOf(
        "android.permission.CAMERA" to "الكاميرا",
        "android.permission.RECORD_AUDIO" to "الميكروفون",
        "android.permission.ACCESS_FINE_LOCATION" to "الموقع الدقيق",
        "android.permission.ACCESS_COARSE_LOCATION" to "الموقع التقريبي",
        "android.permission.READ_CONTACTS" to "قراءة جهات الاتصال",
        "android.permission.WRITE_CONTACTS" to "تعديل جهات الاتصال",
        "android.permission.READ_SMS" to "قراءة الرسائل",
        "android.permission.RECEIVE_SMS" to "استقبال الرسائل",
        "android.permission.SEND_SMS" to "إرسال الرسائل",
        "android.permission.READ_CALL_LOG" to "سجل المكالمات",
        "android.permission.WRITE_CALL_LOG" to "تعديل سجل المكالمات",
        "android.permission.READ_PHONE_STATE" to "حالة الهاتف",
        "android.permission.REQUEST_INSTALL_PACKAGES" to "طلب تثبيت تطبيقات",
        "android.permission.SYSTEM_ALERT_WINDOW" to "الظهور فوق التطبيقات"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        content.text = "جاهز للفحص.\n\nاضغط «فحص التطبيقات» لمراجعة التطبيقات والأذونات الظاهرة للنظام، أو اختر ملف APK لتحليل بياناته الوصفية وبصمته الرقمية.\n\nوجود إذن حساس أو تثبيت التطبيق من خارج المتجر ليس دليلًا قاطعًا على وجود فيروس."
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 24)
            setBackgroundColor(0xFF081423.toInt())
        }
        val scroll = ScrollView(this)
        val title = TextView(this).apply {
            text = "NexaShield"
            textSize = 29f
            setTextColor(0xFF42D6D0.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Android Security Scanner • نسخة أولية قابلة للاختبار"
            textSize = 13f
            setTextColor(0xFFB7C8DA.toInt())
            setPadding(0, 4, 0, 20)
        }
        scanButton = makeButton("فحص التطبيقات المثبتة") { runScan() }
        val apkButton = makeButton("تحليل ملف APK") {
            apkPicker.launch(arrayOf("application/vnd.android.package-archive", "*/*"))
        }
        val shareButton = makeButton("مشاركة التقرير") { shareReport() }
        content = TextView(this).apply {
            textSize = 14f
            setTextColor(0xFFEAF2FA.toInt())
            setPadding(0, 20, 0, 10)
            textDirection = TextView.TEXT_DIRECTION_RTL
            setLineSpacing(5f, 1.0f)
        }
        val disclaimer = TextView(this).apply {
            text = "حدود الفحص: Android يمنع التطبيقات العادية من فحص بيانات التطبيقات الأخرى وملفات النظام المحمية. هذا الإصدار لا يثبت خلو الهاتف من الاختراق ولا يصدر حكمًا نهائيًا بأن تطبيقًا مصاب."
            textSize = 12f
            setTextColor(0xFFFFD58A.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFF332A1B.toInt())
        }
        outer.addView(title)
        outer.addView(subtitle)
        outer.addView(scanButton, fullWidth())
        outer.addView(apkButton, fullWidth())
        outer.addView(shareButton, fullWidth())
        outer.addView(content, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 12 })
        outer.addView(disclaimer, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 14 })
        scroll.addView(outer)
        setContentView(scroll)
    }

    private fun fullWidth() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 9 }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 15f
        setOnClickListener { action() }
    }

    private fun runScan() {
        scanButton.isEnabled = false
        content.text = "جارٍ فحص قائمة التطبيقات والأذونات..."
        Thread {
            val report = try { createDeviceReport() }
            catch (e: Exception) { "تعذر إكمال الفحص: ${e.javaClass.simpleName}: ${e.message}" }
            runOnUiThread {
                lastReport = report
                content.text = report
                scanButton.isEnabled = true
            }
        }.start()
    }

    @Suppress("DEPRECATION")
    private fun installedPackages(): List<PackageInfo> {
        return if (Build.VERSION.SDK_INT >= 33) {
            packageManager.getInstalledPackages(
                PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
            )
        } else {
            packageManager.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        }
    }

    private fun createDeviceReport(): String {
        val packages = installedPackages()
        val findings = mutableListOf<AppFinding>()
        for (info in packages) {
            val appInfo = info.applicationInfo ?: continue
            val packageName = info.packageName
            val label = try { appInfo.loadLabel(packageManager).toString() } catch (_: Exception) { packageName }
            val declared = info.requestedPermissions?.toList().orEmpty()
            val sensitive = declared.filter { sensitivePermissions.containsKey(it) }
            val isSystem = (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
            val reasons = mutableListOf<String>()
            if (sensitive.size >= 3) {
                reasons.add("يطلب ${sensitive.size} أذونات حساسة؛ راجع توافقها مع وظيفة التطبيق")
            }
            val installer = try {
                if (Build.VERSION.SDK_INT >= 30) packageManager.getInstallSourceInfo(packageName).installingPackageName
                else {
                    @Suppress("DEPRECATION")
                    packageManager.getInstallerPackageName(packageName)
                }
            } catch (_: Exception) { null }
            if (!isSystem && installer == null) {
                reasons.add("مصدر التثبيت غير معروف؛ تحقق من مصدر التطبيق")
            }
            if (reasons.isNotEmpty()) {
                findings.add(AppFinding(label, packageName, sensitive.mapNotNull { sensitivePermissions[it] }, reasons))
            }
        }

        val patch = Build.VERSION.SECURITY_PATCH ?: "غير متاح"
        val androidVersion = "${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})"
        val out = StringBuilder()
        out.appendLine("NexaShield — تقرير فحص الجهاز")
        out.appendLine("التاريخ: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())}")
        out.appendLine("إصدار Android: $androidVersion")
        out.appendLine("مستوى تصحيح الأمان: $patch")
        out.appendLine("عدد التطبيقات الظاهرة للفاحص: ${packages.size}")
        out.appendLine("تطبيقات تحتاج مراجعة يدوية: ${findings.size}")
        out.appendLine()
        out.appendLine("نتائج المراجعة:")
        if (findings.isEmpty()) {
            out.appendLine("لم تظهر مؤشرات المراجعة المحددة. هذا لا يعني أن الجهاز خالٍ من البرمجيات الضارة.")
        } else {
            findings.sortedByDescending { it.reasons.size + it.permissions.size }.take(60).forEachIndexed { index, app ->
                out.appendLine("${index + 1}. ${app.label}")
                out.appendLine("   الحزمة: ${app.packageName}")
                if (app.permissions.isNotEmpty()) out.appendLine("   الأذونات الحساسة: ${app.permissions.joinToString("، ")}")
                app.reasons.forEach { out.appendLine("   سبب المراجعة: $it") }
                out.appendLine("   النتيجة: يحتاج مراجعة — ليس حكمًا بأنه فيروس")
                out.appendLine()
            }
        }
        out.appendLine("حدود وملحوظات:")
        out.appendLine("• الأذونات مؤشرات للمراجعة وليست دليل إصابة.")
        out.appendLine("• مصدر التثبيت غير المعروف لا يعني وحده أن التطبيق ضار.")
        out.appendLine("• لا يفحص هذا الإصدار ذاكرة التطبيقات أو ملفات النظام المحمية أو نشاط الشبكة.")
        out.appendLine("• لا يحتوي هذا الإصدار على قاعدة توقيعات malware أو مطابقة CVE مباشرة.")
        out.appendLine("• بعض التطبيقات قد لا تظهر بسبب قيود رؤية الحزم أو إعدادات الشركة المصنّعة.")
        return out.toString()
    }

    private fun inspectApk(uri: Uri) {
        content.text = "جارٍ تحليل ملف APK..."
        Thread {
            val result = try {
                val digest = MessageDigest.getInstance("SHA-256")
                val apkCopy = java.io.File.createTempFile("nexashield-", ".apk", cacheDir)
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        apkCopy.outputStream().use { output ->
                            val buffer = ByteArray(8192)
                            while (true) {
                                val n = input.read(buffer)
                                if (n <= 0) break
                                digest.update(buffer, 0, n)
                                output.write(buffer, 0, n)
                            }
                        }
                    } ?: throw IllegalStateException("تعذر قراءة الملف")
                    val sha = digest.digest().joinToString("") { "%02x".format(it) }
                    val archiveInfo = if (Build.VERSION.SDK_INT >= 33) {
                        packageManager.getPackageArchiveInfo(apkCopy.absolutePath,
                            PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
                    } else {
                        @Suppress("DEPRECATION")
                        packageManager.getPackageArchiveInfo(apkCopy.absolutePath, PackageManager.GET_PERMISSIONS)
                    }
                val permissions = archiveInfo?.requestedPermissions?.toList().orEmpty()
                val sensitive = permissions.filter { sensitivePermissions.containsKey(it) }
                    .mapNotNull { sensitivePermissions[it] }
                buildString {
                    appendLine("NexaShield — تحليل ملف APK")
                    appendLine("SHA-256: $sha")
                    appendLine("اسم الحزمة: ${archiveInfo?.packageName ?: "تعذر استخراجه"}")
                    appendLine("الإصدار: ${archiveInfo?.versionName ?: "غير متاح"}")
                    appendLine("عدد الأذونات المعلنة: ${permissions.size}")
                    appendLine("الأذونات الحساسة: ${if (sensitive.isEmpty()) "لم تُرصد من القائمة المحددة" else sensitive.joinToString("، ")}")
                    appendLine()
                    appendLine("هذا تحليل ثابت أولي للبيانات الوصفية والأذونات فقط. لم يتم تشغيل الملف أو فحص كوده بحثًا عن كل أنواع البرمجيات الضارة.")
                    }
                } finally {
                    apkCopy.delete()
                }
            } catch (e: Exception) { "فشل تحليل APK: ${e.message}" }
            runOnUiThread {
                lastReport = result
                content.text = result
            }
        }.start()
    }

    private fun shareReport() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "NexaShield Security Report")
            putExtra(Intent.EXTRA_TEXT, lastReport)
        }
        startActivity(Intent.createChooser(intent, "مشاركة تقرير NexaShield"))
    }
}
